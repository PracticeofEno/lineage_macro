from __future__ import annotations

import argparse
import json
import os
import socket
import threading
import time
from ctypes import windll
from dataclasses import asdict, dataclass

import win32con
import win32gui

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG_PATH = os.path.join(BASE_DIR, "meat_macro_config.json")
POINT_NAMES = ("start", "end1", "end2", "end3", "end4")


@dataclass(slots=True)
class TargetConfig:
    window_title_prefix: str
    start_screen_pos: list[int]
    end_screen_positions: list[list[int]]


@dataclass(slots=True)
class MacroConfig:
    proxy_host: str
    proxy_port: int
    cycle_interval_seconds: float
    pre_drag_delay_seconds: float
    post_drag_delay_seconds: float
    between_action_delay_seconds: float
    between_window_delay_seconds: float
    targets: dict[str, TargetConfig]


def _default_config() -> MacroConfig:
    return MacroConfig(
        proxy_host="127.0.0.1",
        proxy_port=9998,
        cycle_interval_seconds=1800.0,
        pre_drag_delay_seconds=0.05,
        post_drag_delay_seconds=0.05,
        between_action_delay_seconds=0.15,
        between_window_delay_seconds=0.30,
        targets={
            "server": TargetConfig(
                window_title_prefix="server",
                start_screen_pos=[0, 0],
                end_screen_positions=[[0, 0] for _ in range(4)],
            ),
            "client": TargetConfig(
                window_title_prefix="client",
                start_screen_pos=[0, 0],
                end_screen_positions=[[0, 0] for _ in range(4)],
            ),
        },
    )


def _normalize_point(value) -> list[int]:
    if not isinstance(value, (list, tuple)) or len(value) < 2:
        return [0, 0]
    return [int(value[0]), int(value[1])]


def _normalize_end_positions(target_raw: dict) -> list[list[int]]:
    raw_positions = target_raw.get("end_screen_positions")
    if not isinstance(raw_positions, list) or not raw_positions:
        raw_positions = target_raw.get("end_client_positions")
    if isinstance(raw_positions, list) and raw_positions:
        positions = [_normalize_point(value) for value in raw_positions[:4]]
    else:
        old_end = _normalize_point(target_raw.get("end_client_pos", [0, 0]))
        positions = [old_end[:] for _ in range(4)]

    while len(positions) < 4:
        positions.append([0, 0])
    return positions


def load_config(path: str) -> MacroConfig:
    if not os.path.exists(path):
        config = _default_config()
        save_config(path, config)
        return config

    with open(path, encoding="utf-8") as f:
        raw = json.load(f)

    targets: dict[str, TargetConfig] = {}
    for name in ("server", "client"):
        target_raw = raw.get("targets", {}).get(name, {})
        targets[name] = TargetConfig(
            window_title_prefix=str(target_raw.get("window_title_prefix", name)).strip() or name,
            start_screen_pos=_normalize_point(
                target_raw.get("start_screen_pos", target_raw.get("start_client_pos", [0, 0]))
            ),
            end_screen_positions=_normalize_end_positions(target_raw),
        )

    return MacroConfig(
        proxy_host=str(raw.get("proxy_host", "127.0.0.1")).strip() or "127.0.0.1",
        proxy_port=int(raw.get("proxy_port", 9998)),
        cycle_interval_seconds=float(raw.get("cycle_interval_seconds", 1800.0)),
        pre_drag_delay_seconds=float(raw.get("pre_drag_delay_seconds", 0.05)),
        post_drag_delay_seconds=float(raw.get("post_drag_delay_seconds", 0.05)),
        between_action_delay_seconds=float(raw.get("between_action_delay_seconds", 0.15)),
        between_window_delay_seconds=float(raw.get("between_window_delay_seconds", 0.30)),
        targets=targets,
    )


def save_config(path: str, config: MacroConfig) -> None:
    raw = asdict(config)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=True, indent=2)


class ArduinoProxyClient:
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self._conn: socket.socket | None = None
        self._lock = threading.Lock()

    def close(self) -> None:
        with self._lock:
            self._close_unlocked()

    def _close_unlocked(self) -> None:
        if self._conn is None:
            return
        try:
            self._conn.close()
        except OSError:
            pass
        self._conn = None

    def _connect_unlocked(self) -> None:
        conn = socket.create_connection((self.host, self.port), timeout=3)
        conn.settimeout(3)
        self._conn = conn

    def command(self, cmd: str) -> str:
        with self._lock:
            if self._conn is None:
                self._connect_unlocked()

            try:
                return self._send_and_read_unlocked(cmd)
            except OSError:
                self._close_unlocked()
                self._connect_unlocked()
                return self._send_and_read_unlocked(cmd)

    def _send_and_read_unlocked(self, cmd: str) -> str:
        assert self._conn is not None
        self._conn.sendall((cmd + "\n").encode("utf-8"))
        buf = b""
        while b"\n" not in buf:
            chunk = self._conn.recv(256)
            if not chunk:
                raise OSError("proxy closed connection")
            buf += chunk
        return buf.split(b"\n", 1)[0].decode("utf-8", errors="replace").strip()

    def expect_ok(self, cmd: str) -> None:
        resp = self.command(cmd)
        if resp != "OK":
            raise RuntimeError(f"proxy command failed: {cmd} -> {resp}")

    def init_cursor(self) -> None:
        self.expect_ok("INIT")

    def move_mouse_abs(self, x: int, y: int) -> None:
        self.expect_ok(f"MM,{x},{y}")

    def left_down(self) -> None:
        self.expect_ok("LD")

    def left_up(self) -> None:
        self.expect_ok("LU")

    def key_press(self, vk: int) -> None:
        self.expect_ok(f"KP,{vk}")


class WindowResolver:
    def __init__(self, title_prefix: str):
        self._title_prefix = title_prefix
        self._title_prefix_lower = title_prefix.casefold()
        self._hwnd: int | None = None

    def resolve(self) -> tuple[int, str]:
        if self._hwnd is not None and win32gui.IsWindow(self._hwnd):
            title = win32gui.GetWindowText(self._hwnd)
            if title and title.casefold().startswith(self._title_prefix_lower):
                return self._hwnd, title

        matches: list[tuple[int, str]] = []

        def callback(hwnd: int, _extra) -> None:
            if not win32gui.IsWindowVisible(hwnd):
                return
            title = win32gui.GetWindowText(hwnd)
            if not title:
                return
            if title.casefold().startswith(self._title_prefix_lower):
                matches.append((hwnd, title))

        win32gui.EnumWindows(callback, None)
        if not matches:
            raise RuntimeError(f"window not found: {self._title_prefix}")

        exact = [entry for entry in matches if entry[1].casefold() == self._title_prefix_lower]
        self._hwnd, title = exact[0] if exact else matches[0]
        return self._hwnd, title


def focus_window(hwnd: int) -> None:
    if win32gui.IsIconic(hwnd):
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
    windll.user32.keybd_event(0, 0, 0, 0)
    win32gui.SetForegroundWindow(hwnd)
    time.sleep(0.05)


def move_window_to_origin(hwnd: int) -> tuple[int, int, int, int]:
    if win32gui.IsIconic(hwnd):
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    width = right - left
    height = bottom - top
    win32gui.MoveWindow(hwnd, 0, 0, width, height, True)
    time.sleep(0.05)
    return win32gui.GetWindowRect(hwnd)


class MeatMacro:
    def __init__(self, config_path: str):
        self._config_path = config_path
        self._config = load_config(config_path)
        self._proxy = ArduinoProxyClient(self._config.proxy_host, self._config.proxy_port)
        self._loop_thread: threading.Thread | None = None
        self._loop_stop_event = threading.Event()

    def close(self) -> None:
        self.stop_loop()
        self._proxy.close()

    def reload(self) -> None:
        was_running = self.loop_running
        self.stop_loop()
        self._config = load_config(self._config_path)
        self._proxy.close()
        self._proxy = ArduinoProxyClient(self._config.proxy_host, self._config.proxy_port)
        if was_running:
            print("[reload] scheduled loop stopped")

    @property
    def config(self) -> MacroConfig:
        return self._config

    def resolve_target(self, target_name: str) -> tuple[TargetConfig, int, str]:
        target = self._config.targets[target_name]
        resolver = WindowResolver(target.window_title_prefix)
        hwnd, title = resolver.resolve()
        return target, hwnd, title

    def set_point(self, target_name: str, point_name: str, x: int, y: int) -> None:
        if point_name not in POINT_NAMES:
            raise RuntimeError(f"unknown point: {point_name}")

        target = self._config.targets[target_name]
        screen_pos = [int(x), int(y)]

        if point_name == "start":
            target.start_screen_pos = screen_pos
        else:
            target.end_screen_positions[int(point_name[-1]) - 1] = screen_pos

        save_config(self._config_path, self._config)
        print(f"[set] saved {target_name} {point_name}: {screen_pos}")

    def run_target(self, target_name: str) -> None:
        target, hwnd, title = self.resolve_target(target_name)
        rect = move_window_to_origin(hwnd)
        focus_window(hwnd)

        start_screen = tuple(target.start_screen_pos)

        print(
            f"[run] {target_name} -> {title} "
            f"window_rect={rect} "
            f"start={target.start_screen_pos}"
        )

        for idx, end_screen_pos in enumerate(target.end_screen_positions, start=1):
            end_screen = tuple(end_screen_pos)
            self._proxy.init_cursor()
            self._proxy.move_mouse_abs(*start_screen)
            time.sleep(self._config.pre_drag_delay_seconds)
            self._proxy.left_down()
            time.sleep(self._config.pre_drag_delay_seconds)
            self._proxy.move_mouse_abs(*end_screen)
            time.sleep(self._config.post_drag_delay_seconds)
            self._proxy.left_up()
            time.sleep(self._config.post_drag_delay_seconds)
            self._proxy.key_press(ord("1"))
            self._proxy.key_press(win32con.VK_RETURN)
            print(
                f"[run] {target_name} action {idx}/4 "
                f"end={end_screen_pos}"
            )
            if idx < len(target.end_screen_positions):
                time.sleep(self._config.between_action_delay_seconds)

    def run_many(self, target_names: list[str]) -> None:
        for idx, target_name in enumerate(target_names):
            self.run_target(target_name)
            if idx + 1 < len(target_names):
                time.sleep(self._config.between_window_delay_seconds)

    @property
    def loop_running(self) -> bool:
        return self._loop_thread is not None and self._loop_thread.is_alive()

    def start_loop(self, target_names: list[str]) -> None:
        if self.loop_running:
            raise RuntimeError("scheduled loop is already running")

        self._loop_stop_event.clear()
        self._loop_thread = threading.Thread(
            target=self._loop_worker,
            args=(list(target_names),),
            daemon=True,
        )
        self._loop_thread.start()
        print(
            f"[loop] started for {', '.join(target_names)} "
            f"every {self._config.cycle_interval_seconds:.0f}s"
        )

    def stop_loop(self) -> None:
        if not self.loop_running:
            return
        self._loop_stop_event.set()
        assert self._loop_thread is not None
        self._loop_thread.join()
        self._loop_thread = None
        print("[loop] stopped")

    def _loop_worker(self, target_names: list[str]) -> None:
        while not self._loop_stop_event.is_set():
            cycle_started = time.monotonic()
            started_text = time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"[loop] cycle started at {started_text}")
            try:
                self.run_many(target_names)
            except Exception as exc:
                print(f"[loop] cycle error: {exc}")

            wait_seconds = self._config.cycle_interval_seconds - (time.monotonic() - cycle_started)
            if wait_seconds <= 0:
                continue

            next_run_text = time.strftime(
                "%Y-%m-%d %H:%M:%S",
                time.localtime(time.time() + wait_seconds),
            )
            print(f"[loop] next cycle at {next_run_text}")
            if self._loop_stop_event.wait(wait_seconds):
                break

    def print_status(self) -> None:
        print(f"[status] proxy={self._config.proxy_host}:{self._config.proxy_port}")
        print(f"[status] cycle_interval_seconds={self._config.cycle_interval_seconds}")
        print(f"[status] loop_running={self.loop_running}")
        for name in ("server", "client"):
            target = self._config.targets[name]
            try:
                _, hwnd, title = self.resolve_target(name)
                window_info = f"{title} ({hwnd})"
            except Exception as exc:
                window_info = f"unresolved ({exc})"
            print(
                f"[status] {name}: "
                f"prefix={target.window_title_prefix}, "
                f"start={target.start_screen_pos}, "
                f"ends={target.end_screen_positions}, "
                f"window={window_info}"
            )


def parse_target_names(value: str) -> list[str]:
    if value == "all":
        return ["server", "client"]
    if value not in {"server", "client"}:
        raise RuntimeError(f"unknown target: {value}")
    return [value]


def print_help() -> None:
    print("Commands")
    print("  status")
    print("  set start server <x> <y>")
    print("  set end1 server <x> <y>")
    print("  set end2 server <x> <y>")
    print("  set end3 server <x> <y>")
    print("  set end4 server <x> <y>")
    print("  set start client <x> <y>")
    print("  set end1 client <x> <y>")
    print("  set end2 client <x> <y>")
    print("  set end3 client <x> <y>")
    print("  set end4 client <x> <y>")
    print("  run server")
    print("  run client")
    print("  run all")
    print("  loop start server")
    print("  loop start client")
    print("  loop start all")
    print("  loop stop")
    print("  reload")
    print("  quit")


def run_shell(app: MeatMacro) -> int:
    print_help()
    while True:
        try:
            raw = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        if not raw:
            continue

        try:
            parts = raw.split()
            if parts == ["status"]:
                app.print_status()
            elif parts == ["reload"]:
                app.reload()
                print("[reload] config reloaded")
            elif parts == ["loop", "stop"]:
                app.stop_loop()
            elif parts == ["quit"] or parts == ["exit"]:
                return 0
            elif len(parts) == 5 and parts[0] == "set":
                app.set_point(parts[2], parts[1], int(parts[3]), int(parts[4]))
            elif len(parts) == 2 and parts[0] == "run":
                app.run_many(parse_target_names(parts[1]))
            elif len(parts) == 3 and parts[0] == "loop" and parts[1] == "start":
                app.start_loop(parse_target_names(parts[2]))
            elif parts == ["help"]:
                print_help()
            else:
                print("[error] unknown command")
                print_help()
        except Exception as exc:
            print(f"[error] {exc}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Drag using screen coordinates, then press 1 and Enter, repeated for server/client windows."
    )
    parser.add_argument(
        "--config",
        default=DEFAULT_CONFIG_PATH,
        help="Path to the JSON config file.",
    )
    parser.add_argument(
        "--set",
        choices=POINT_NAMES,
        help="Set a point directly by absolute screen coordinates.",
    )
    parser.add_argument(
        "--target",
        choices=["server", "client"],
        help="Target window for --set or --run.",
    )
    parser.add_argument(
        "--x",
        type=int,
        help="X coordinate for --set.",
    )
    parser.add_argument(
        "--y",
        type=int,
        help="Y coordinate for --set.",
    )
    parser.add_argument(
        "--run",
        choices=["server", "client", "all"],
        help="Run the macro once for the selected target set.",
    )
    parser.add_argument(
        "--loop",
        choices=["server", "client", "all"],
        help="Run the macro repeatedly on a schedule until stopped.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    app = MeatMacro(args.config)
    try:
        if args.set:
            if not args.target:
                raise SystemExit("--set requires --target")
            if args.x is None or args.y is None:
                raise SystemExit("--set requires --x and --y")
            app.set_point(args.target, args.set, args.x, args.y)
            return 0

        if args.run:
            app.run_many(parse_target_names(args.run))
            return 0

        if args.loop:
            app.start_loop(parse_target_names(args.loop))
            try:
                while app.loop_running:
                    time.sleep(1)
            except KeyboardInterrupt:
                print()
                app.stop_loop()
            return 0

        return run_shell(app)
    finally:
        app.close()


if __name__ == "__main__":
    raise SystemExit(main())
